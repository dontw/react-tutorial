
// import foo from "./util/es6.util";
// foo();

// import { multi , add } from "./util/es6.util";
// console.log('add',add(1,1));
// console.log("multi", multi(6, 2));


///////////

console.log('app.js');


import child from './child';

import foo, { multi , add } from "./util/es6.util";
foo();
console.log('add',add(1,1));
console.log("multi", multi(6, 2));

// var util = require('./util/es6.util');