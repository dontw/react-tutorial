import foo from "./util/es6.util";
console.log('child');


foo();