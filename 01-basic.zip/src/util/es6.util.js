export const add = (num1, num2)=> {
  return num1 + num2;
}

/**
 * @param {number} num1
 * @param {number} num2
 * @return {number}
 */
export function sub(num1, num2) {
  return num1 - num2;
}
/**
 * @param {number} num1
 * @param {number} num2
 * @return {number}
 */
export function multi(num1, num2) {
  return num1 * num2;
}


const foo = function(){
  console.log('foo');
}

export default foo;