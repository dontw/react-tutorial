import React from 'react';
import { connect } from 'react-redux';

const MemberComponent = ({ name, age }) => (
  <div>
    <p>name:{name}</p>
    <p>age:{age}</p>
  </div>
);

const mapStateToProps = state => ({
  name: state.member.name,
  age: state.member.age,
});

const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(MemberComponent);
