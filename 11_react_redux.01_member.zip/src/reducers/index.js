import { combineReducers } from 'redux';
import todos from './todos';
import member from './member';

const todoApp = combineReducers({
  todos,
  member,
});

export default todoApp;
