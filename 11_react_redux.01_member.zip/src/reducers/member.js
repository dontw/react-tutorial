
const DEFAULT_VALUE = {
  name: 'milkmidi',
  age: 18,
};
const member = (state = DEFAULT_VALUE, action) => {
  switch (action.type) {
    default:
      return state;
  }
};

export default member;
