import React, { Component } from 'react';


export default class TodoForm extends Component {
  submitHandler =(e) => {
    e.preventDefault();
    if (!this.input.value.trim()) {
      return;
    }
    this.props.addTodo(this.input.value);
    this.input.value = '';
  }
  render() {
    return (
      <form onSubmit={this.submitHandler}>
        <input ref={(node) => { this.input = node; }} />
        <button type="submit">Add Todo</button>
      </form>
    );
  }
}
