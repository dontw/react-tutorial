import React from 'react';
import AddTodo from '../containers/AddTodo';
import VisibleTodoList from '../containers/VisibleTodoList';

import ClearTodoCount from '../containers/ClearTodoCount';
import MemberContainer from '../containers/MemberContainer';

const App = () => (
  <div className="app">
    <AddTodo />
    <VisibleTodoList />
    <ClearTodoCount />
    <MemberContainer />
  </div>
);

export default App;
